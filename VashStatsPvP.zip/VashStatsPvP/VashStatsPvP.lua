--[[
    Vash Stats PvP  -  WoW 3.3.5a
    Autor: Vash
    La funcion GetStatsText() es la logica original del WeakAura "Stats PvP", sin cambios.
    Comando: /vstats  (abre configuracion)
]]

local ADDON = "VashStatsPvP"

------------------------------------------------------------------
-- Configuracion por defecto
------------------------------------------------------------------
local DEFAULTS = {
    shown       = true,
    locked      = false,
    fontPath    = "Fonts\\FRIZQT__.TTF",
    fontName    = "Friz Quadrata TT",
    fontSize    = 12,
    outline     = "OUTLINE",
    shadow      = false,
    scale       = 1,
    alpha       = 1,
    useColor    = false,
    color       = { r = 1, g = 1, b = 1 },
    showIcons   = true,
    iconSize    = 0,   -- 0 = automatico (fuente + 2)
    iconY       = 0,
    point       = "CENTER",
    relPoint    = "CENTER",
    x           = 0,
    y           = 0,
}

local function CopyTable(t)
    local n = {}
    for k, v in pairs(t) do
        n[k] = (type(v) == "table") and CopyTable(v) or v
    end
    return n
end

local function ApplyDefaults(db)
    for k, v in pairs(DEFAULTS) do
        if db[k] == nil then
            db[k] = (type(v) == "table") and CopyTable(v) or v
        end
    end
    if type(db.color) ~= "table" then db.color = CopyTable(DEFAULTS.color) end
end

local db

------------------------------------------------------------------
-- LOGICA ORIGINAL DEL WEAKAURA (sin cambios)
------------------------------------------------------------------
local function GetStatsText()
    local _, class = UnitClass("player")
    
    local classIcons = {
        WARRIOR     = "Interface\\Icons\\ClassIcon_Warrior",
        PALADIN     = "Interface\\Icons\\ClassIcon_Paladin",
        HUNTER      = "Interface\\Icons\\ClassIcon_Hunter",
        ROGUE       = "Interface\\Icons\\ClassIcon_Rogue",
        PRIEST      = "Interface\\Icons\\ClassIcon_Priest",
        DEATHKNIGHT = "Interface\\Icons\\Spell_DeathKnight_UnholyPresence",
        SHAMAN      = "Interface\\Icons\\ClassIcon_Shaman",
        MAGE        = "Interface\\Icons\\ClassIcon_Mage",
        WARLOCK     = "Interface\\Icons\\ClassIcon_Warlock",
        DRUID       = "Interface\\Icons\\ClassIcon_Druid",
    }
    
    local statIcons = {
        ARMOR = "Interface\\Icons\\inv_chest_plate10",
        HIT = "Interface\\Icons\\ability_hunter_snipershot",
        CRIT = "Interface\\Icons\\ability_criticalstrike",
        HASTE = "Interface\\Icons\\spell_nature_bloodlust",
        ARP = "Interface\\Icons\\inv_axe_09",
        SPEN = "Interface\\Icons\\inv_misc_gem_sapphire_02",
        MP5 = "Interface\\Icons\\inv_drink_18",
        EXP = "Interface\\Icons\\ability_warrior_warcry",
        DODGE = "Interface\\Icons\\ability_parry",
        RESI = "Interface\\Icons\\spell_holy_devotionaura",
        SHADOW = "Interface\\Icons\\Spell_Shadow_ShadowWordPain",
    }
    
    -- =============================================================
    -- AJUSTE DE TEXTO
    -- =============================================================
    -- Divide solamente los valores que pueden hacerse demasiado largos.
    -- No modifica ningun calculo ni estadistica.
    
    local function FormatPercentValue(basePercent, totalPercent, hasTalent)
        
        if hasTalent then
            
            return string.format(
                "%.2f%%/\n%.2f%%T",
                basePercent,
                totalPercent
            )
            
        else
            
            return string.format(
                "%.2f%%",
                basePercent
            )
        end
    end
    
    -- Icono de clase
    local icon = classIcons[class] or ""
    local iconTag = string.format("|T%s:22:22:0:-10|t", icon)
    
    -- Estadisticas principales
    local int = select(2, UnitStat("player", 4))
    local spi = select(2, UnitStat("player", 5))
    local agi = select(2, UnitStat("player", 2))
    local str = select(2, UnitStat("player", 1))
    
    -- Attack Power
    local base, pos, neg = UnitAttackPower("player")
    local ap = base + pos + neg
    
    -- Ranged Attack Power
    local rbase, rpos, rneg = UnitRangedAttackPower("player")
    local rap = rbase + rpos + rneg
    
    -- Spell Power
    local sp = GetSpellBonusDamage(2)
    
    -- Healers
    local healerClasses = {
        PRIEST = true,
        DRUID = true,
        SHAMAN = true
    }
    
    local isHealer = healerClasses[class] or (
        class == "PALADIN" and sp > ap and int > str
    )
    
    -- Poder principal y tipo de Hit
    local pw, hitID
    
    if class == "SHAMAN" or class == "DRUID" then
        
        pw = (ap > sp) and ap or sp
        hitID = (ap > sp) and 6 or 8
        
    elseif isHealer
    or class == "MAGE"
    or class == "WARLOCK"
    or class == "PRIEST" then
        
        pw = sp
        hitID = 8
        
    elseif class == "HUNTER" then
        
        pw = rap
        hitID = 7
        
    else
        
        pw = ap
        hitID = 6
    end
    
    -- Chaman Restauracion: el PW muestra el poder de sanacion en vez del de dano
    if class == "SHAMAN" and sp > ap then
        local _, _, tab1 = GetTalentTabInfo(1)
        local _, _, tab2 = GetTalentTabInfo(2)
        local _, _, tab3 = GetTalentTabInfo(3)
        tab1, tab2, tab3 = tab1 or 0, tab2 or 0, tab3 or 0
        
        if tab3 > tab1 and tab3 > tab2 then
            pw = GetSpellBonusHealing()
        end
    end
    
    -- Armor
    local armor = select(2, UnitArmor("player"))
    local mitigation = armor / (armor + 15232.5) * 100
    
    -- =============================================================
    -- HIT
    -- =============================================================
    
    local hit = GetCombatRating(hitID)
    local hitp = GetCombatRatingBonus(hitID)
    
    -- Buscar rango de talento
    local function GetTalentRankByName(names)
        
        for tab = 1, 3 do
            
            local numTalents = GetNumTalents(tab)
            
            if numTalents then
                
                for talent = 1, numTalents do
                    
                    local name, _, _, _, rank = GetTalentInfo(tab, talent)
                    
                    if name then
                        
                        for _, wantedName in ipairs(names) do
                            
                            if name == wantedName then
                                return rank or 0
                            end
                        end
                    end
                end
            end
        end
        
        return 0
    end
    
    -- Porcentaje adicional de Hit por talento
    local talentHit = 0
    
    -- =============================================================
    -- SOLO ESTAS 6 CLASES RECIBEN EL BONUS DE HIT
    -- =============================================================
    
    if class == "WARRIOR" then
        
        -- Precision
        -- 1% por punto, maximo 3%
        local rank = GetTalentRankByName({
                "Precision",
                "Precisión"
        })
        
        talentHit = rank * 1
        
    elseif class == "ROGUE" then
        
        -- Precision
        -- 1% por punto, maximo 5%
        local rank = GetTalentRankByName({
                "Precision",
                "Precisión"
        })
        
        talentHit = rank * 1
        
    elseif class == "HUNTER" then
        
        -- =========================================================
        -- HUNTER - PUNTERIA ENFOCADA
        -- Arbol Punteria = 2
        -- Posicion = 2
        --
        -- 1/3 = +1% Hit
        -- 2/3 = +2% Hit
        -- 3/3 = +3% Hit
        -- =========================================================
        
        local _, _, _, _, hunterHitRank = GetTalentInfo(2, 2)
        
        hunterHitRank = hunterHitRank or 0
        
        talentHit = hunterHitRank
        
    elseif class == "PRIEST" then
        
        -- Shadow Focus
        -- 1% por punto, maximo 3%
        local rank = GetTalentRankByName({
                "Shadow Focus",
                "Enfoque de las Sombras"
        })
        
        talentHit = rank * 1
        
    elseif class == "SHAMAN" then
        
        -- Elemental Precision
        -- 1% por punto, maximo 3%
        local rank = GetTalentRankByName({
                "Elemental Precision",
                "Precisión elemental"
        })
        
        talentHit = rank * 1
        
    elseif class == "DRUID" then
        
        -- Improved Faerie Fire
        -- 1% por punto, maximo 3%
        local rank = GetTalentRankByName({
                "Improved Faerie Fire",
                "Fuego feérico mejorado"
        })
        
        talentHit = rank * 1
    end
    
    -- Porcentaje final con talento
    local displayHitPercent = hitp + talentHit
    
    -- =============================================================
    -- MOSTRAR HIT
    -- =============================================================
    
    local hitDisplay
    
    if talentHit > 0 then
        
        hitDisplay = FormatPercentValue(
            hitp,
            displayHitPercent,
            true
        )
        
    else
        
        hitDisplay = FormatPercentValue(
            hitp,
            displayHitPercent,
            false
        )
    end
    
    -- =============================================================
    -- CRIT
    -- =============================================================
    
    local crit, critLabel
    
    if class == "HUNTER" then
        
        crit = GetRangedCritChance()
        critLabel = "Crit"
        
    elseif class == "SHAMAN" or class == "DRUID" then
        
        crit = (sp > ap) and GetSpellCritChance(2) or GetCritChance()
        critLabel = (sp > ap) and "Spell Crit" or "Crit"
        
    elseif isHealer
    or class == "MAGE"
    or class == "WARLOCK"
    or class == "PRIEST" then
        
        crit = GetSpellCritChance(2)
        critLabel = "Spell Crit"
        
    else
        
        crit = GetCritChance()
        critLabel = "Crit"
    end
    
    -- =============================================================
    -- HASTE
    -- =============================================================
    
    local hasteRating, hastePercent
    
    if class == "HUNTER" then
        
        hasteRating = GetCombatRating(CR_HASTE_RANGED)
        hastePercent = GetCombatRatingBonus(CR_HASTE_RANGED)
        
    else
        
        -- Haste segun clase/spec: melee o hechizo
        local hasteCR = CR_HASTE_SPELL
        
        if class == "WARRIOR" or class == "ROGUE" or class == "DEATHKNIGHT" then
            hasteCR = CR_HASTE_MELEE
        elseif class == "PALADIN" then
            if not isHealer then
                hasteCR = CR_HASTE_MELEE
            end
        elseif class == "SHAMAN" or class == "DRUID" then
            if ap > sp then
                hasteCR = CR_HASTE_MELEE
            end
        end
        
        hasteRating = GetCombatRating(hasteCR)
        hastePercent = GetCombatRatingBonus(hasteCR)
    end
    
    -- =============================================================
    -- CLASES QUE MUESTRAN ArP
    -- =============================================================
    
    local validClasses = {
        WARRIOR = true,
        ROGUE = true,
        DEATHKNIGHT = true,
        DRUID = true,
        PALADIN = true,
        HUNTER = true
    }
    
    -- =============================================================
    -- ARMOR PENETRATION
    -- =============================================================
    
    local arpLine = ""
    
    if validClasses[class] then
        
        -- Valor ORIGINAL de ArP
        local arpRating = GetCombatRating(CR_ARMOR_PENETRATION)
        local arpPercent = GetCombatRatingBonus(CR_ARMOR_PENETRATION)
        
        -- Porcentaje que se mostrara
        local displayArpPercent = arpPercent
        
        local arpHasTalent = false
        
        -- =========================================================
        -- GUERRERO
        -- =========================================================
        
        if class == "WARRIOR" then
            
            local stance = GetShapeshiftForm()
            
            -- 1 = Actitud de batalla
            -- 2 = Actitud defensiva
            -- 3 = Actitud rabiosa
            
            if stance == 1 then
                
                displayArpPercent = arpPercent + 10
                arpHasTalent = true
            end
        end
        
        -- =========================================================
        -- PICARO
        -- ESPADAS DENTADAS / SERRATED BLADES
        -- =========================================================
        
        if class == "ROGUE" then
            
            -- Cada punto del talento da +3% ArP
            --
            -- 1/3 = +3%
            -- 2/3 = +6%
            -- 3/3 = +9%
            
            local serratedBladesRank = GetTalentRankByName({
                    "Serrated Blades",
                    "Espadas dentadas"
            })
            
            if serratedBladesRank and serratedBladesRank > 0 then
                
                local serratedBladesBonus = serratedBladesRank * 3
                
                displayArpPercent = arpPercent + serratedBladesBonus
                arpHasTalent = true
            end
        end
        
        -- =========================================================
        -- CABALLERO DE LA MUERTE
        -- BLOOD GORGED
        -- =========================================================
        
        if class == "DEATHKNIGHT" then
            
            -- Blood Gorged:
            -- 2% de ArP por cada punto del talento.
            --
            -- 5/5 = +10%
            -- 4/5 = +8%
            -- 3/5 = +6%
            -- 2/5 = +4%
            -- 1/5 = +2%
            
            local _, _, _, _, bloodGorgedRank = GetTalentInfo(1, 27)
            
            if bloodGorgedRank and bloodGorgedRank > 0 then
                
                local bloodGorgedBonus = bloodGorgedRank * 2
                
                displayArpPercent = arpPercent + bloodGorgedBonus
                arpHasTalent = true
            end
        end
        
        -- =========================================================
        -- MOSTRAR ArP
        -- =========================================================
        
        local arpDisplay
        
        if arpHasTalent then
            
            arpDisplay = FormatPercentValue(
                arpPercent,
                displayArpPercent,
                true
            )
            
        else
            
            arpDisplay = FormatPercentValue(
                arpPercent,
                displayArpPercent,
                false
            )
        end
        
        arpLine = string.format(
            "|T%s:16:16:0:-10|t |cFFC69B6DArP: %d (%s)|r",
            statIcons.ARP,
            arpRating,
            arpDisplay
        )
        
    else
        
        arpLine = string.format(
            "|T%s:16:16:0:-10|t |cFFC69B6DArP: N/A|r",
            statIcons.ARP
        )
    end
    
    -- Spell Penetration
    local spen = GetSpellPenetration()
    
    -- MP5
    local _, castingMP5 = GetManaRegen()
    local mp5 = castingMP5 * 5
    
    -- Expertise
    local expertise = GetExpertise()
    local expertiseBonus = GetExpertisePercent()
    
    -- Resilience
    local res = GetCombatRating(15)
    local resp = GetCombatRatingBonus(15)
    
    -- Dodge
    local dodge = GetDodgeChance()
    
    -- Resistencias
    local fRes = select(2, UnitResistance("player", 2)) or 0
    local nRes = select(2, UnitResistance("player", 3)) or 0
    local frRes = select(2, UnitResistance("player", 4)) or 0
    local sRes = select(2, UnitResistance("player", 5)) or 0
    local aRes = select(2, UnitResistance("player", 6)) or 0
    
    -- =============================================================
    -- RESISTENCIAS
    -- =============================================================
    
    local resValues = {
        string.format("|cFFFF8000%d|r", fRes),
        string.format("|cFF4DFF4D%d|r", nRes),
        string.format("|cFF80FFFF%d|r", frRes),
        string.format("|cFF8080FF%d|r", sRes),
        string.format("|cFFFF80FF%d|r", aRes)
    }
    
    -- =============================================================
    -- CONTAR RESISTENCIAS ACTIVAS
    -- =============================================================
    
    local rawValues = {
        fRes,
        nRes,
        frRes,
        sRes,
        aRes
    }
    
    local activeCount = 0
    
    for i = 1, 5 do
        if rawValues[i] > 0 then
            activeCount = activeCount + 1
        end
    end
    
    -- =============================================================
    -- CONSTRUIR RES
    -- =============================================================
    
    local resLine = string.format(
        "|T%s:16:16:0:-10|t |cFFA335EERES: |r",
        statIcons.SHADOW
    )
    
    -- =============================================================
    -- 0 O 1 RESISTENCIA ACTIVA
    -- TODO EN UNA SOLA FILA
    -- =============================================================
    
    if activeCount <= 1 then
        
        for i = 1, 5 do
            
            if i > 1 then
                resLine = resLine .. "   "
            end
            
            resLine = resLine .. resValues[i]
        end
        
        -- =============================================================
        -- 2 O MAS RESISTENCIAS ACTIVAS
        -- LAS PRIMERAS 2 ACTIVAS ARRIBA
        -- TODO LO DEMAS ABAJO
        -- =============================================================
        
    else
        
        local topRow = {}
        local bottomRow = {}
        
        for i = 1, 5 do
            
            if rawValues[i] > 0 and #topRow < 2 then
                table.insert(topRow, resValues[i])
            else
                table.insert(bottomRow, resValues[i])
            end
            
        end
        
        -- Fila superior
        for i, value in ipairs(topRow) do
            
            if i > 1 then
                resLine = resLine .. "   "
            end
            
            resLine = resLine .. value
        end
        
        -- Fila inferior
        if #bottomRow > 0 then
            
            resLine = resLine .. "\n"
            
            for i, value in ipairs(bottomRow) do
                
                if i > 1 then
                    resLine = resLine .. "   "
                end
                
                resLine = resLine .. value
            end
        end
    end
    
    -- =============================================================
    -- QUE LINEAS SE MUESTRAN SEGUN LA CLASE
    -- =============================================================
    
    -- Clases de magia y healers: sin ArP, Expertise ni Dodge.
    -- Druida/Chaman cuentan como magia/healer solo si su poder de hechizo
    -- es mayor que su poder de ataque (resto/balance, elemental/restauracion).
    local hideMeleeStats = class == "PRIEST"
        or class == "MAGE"
        or class == "WARLOCK"
        or ((class == "SHAMAN" or class == "DRUID") and sp > ap)
        or (class == "PALADIN" and isHealer)
    
    -- Intelecto / Espiritu solo en las clases que lo necesitan
    local intSpiLine
    
    if class == "WARRIOR" or class == "ROGUE" or class == "DEATHKNIGHT" then
        
        intSpiLine = nil
        
    elseif class == "HUNTER" then
        
        intSpiLine = string.format("|cFF6495EDInt: %d|r", int)
        
    else
        
        intSpiLine = string.format("|cFF6495EDInt: %d|r / |cFFFFFFFFSpi: %d|r", int, spi)
    end
    
    -- =============================================================
    -- TEXTO FINAL
    -- SIN FILAS VACIAS
    -- =============================================================
    
    local lines = {}
    
    lines[#lines + 1] = string.format("%s |cFFFFFFFFSTATS PVP|r", iconTag)
    
    if intSpiLine then
        lines[#lines + 1] = intSpiLine
    end
    
    -- Agilidad solo en clases que la necesitan (chaman solo mejora)
    local showAgi = class == "PALADIN"
        or class == "HUNTER"
        or class == "WARRIOR"
        or class == "DEATHKNIGHT"
        or class == "DRUID"
        or class == "ROGUE"
        or (class == "SHAMAN" and ap > sp)
    
    if showAgi then
        lines[#lines + 1] = string.format("|cFF90EE90PW: %d / Agi: %d|r", pw, agi)
    else
        lines[#lines + 1] = string.format("|cFF90EE90PW: %d|r", pw)
    end
    lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFFFFFF99Arm: %d (%.2f%%)|r", statIcons.ARMOR, armor, mitigation)
    lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFFFFFFFFHit: %d (%s)|r", statIcons.HIT, hit, hitDisplay)
    lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFFFF5050%s: %.2f%%|r", statIcons.CRIT, critLabel, crit)
    lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFFFFFF00Haste: %d (%.2f%%)|r", statIcons.HASTE, hasteRating, hastePercent)
    
    if not hideMeleeStats and class ~= "SHAMAN" then
        lines[#lines + 1] = arpLine
    end
    
    -- SPen: no se muestra en Guerrero, Paladin ni Picaro (DK y Druida feral si lo muestran)
    local hideSpen = class == "WARRIOR"
        or class == "PALADIN"
        or class == "ROGUE"
    
    if not hideSpen then
        lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFF3399FFSPen: %d|r", statIcons.SPEN, spen)
    end
    -- MP5 solo en clases que usan mana (Paladin solo si es healer holy, Chaman y Druida solo si NO son mejora/feral), excepto cazador
    local showMP5 = (class == "PALADIN" and isHealer)
        or class == "PRIEST"
        or (class == "SHAMAN" and sp > ap)
        or (class == "DRUID" and sp > ap)
        or class == "MAGE"
        or class == "WARLOCK"
    
    if showMP5 then
        lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFF87CEFAMP5: %d|r", statIcons.MP5, mp5)
    end
    lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFFFFFFFFResi: %d (%.2f%%)|r", statIcons.RESI, res, resp)
    lines[#lines + 1] = resLine
    
    if not hideMeleeStats and class ~= "HUNTER" then
        lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFFFFC0CBExp: %d (%.2f%%)|r", statIcons.EXP, expertise, expertiseBonus)
    end
    
    if not hideMeleeStats then
        lines[#lines + 1] = string.format("|T%s:16:16:0:-10|t |cFFB57EDCDodge: %.2f%%|r", statIcons.DODGE, dodge)
    end
    
    return table.concat(lines, "\n") .. "\n"
end
------------------------------------------------------------------
-- FIN DE LA LOGICA ORIGINAL
------------------------------------------------------------------

------------------------------------------------------------------
-- Ventana principal
------------------------------------------------------------------
local main = CreateFrame("Frame", "VashStatsPvPFrame", UIParent)
main:SetSize(150, 200)
main:SetFrameStrata("MEDIUM")
main:SetMovable(true)
main:SetClampedToScreen(true)
main:EnableMouse(true)
main:RegisterForDrag("LeftButton")

local text = main:CreateFontString(nil, "OVERLAY")
text:SetPoint("TOPLEFT", main, "TOPLEFT", 0, 0)
text:SetJustifyH("LEFT")
text:SetJustifyV("TOP")

main:SetScript("OnDragStart", function(self)
    if not db.locked then self:StartMoving() end
end)
main:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint()
    db.point, db.relPoint, db.x, db.y = p, rp, x, y
end)
main:SetScript("OnMouseUp", function(self, button)
    if button == "RightButton" and IsShiftKeyDown() then
        VashStatsPvP_OpenConfig()
    end
end)

local FALLBACK_FONT = "Fonts\\FRIZQT__.TTF"

local function ApplyFont()
    local flags = db.outline
    if flags == "NONE" then flags = "" end
    local ok = text:SetFont(db.fontPath, db.fontSize, flags)
    if not ok then
        text:SetFont(FALLBACK_FONT, db.fontSize, flags)
    end
    if db.shadow then
        text:SetShadowColor(0, 0, 0, 1)
        text:SetShadowOffset(1, -1)
    else
        text:SetShadowOffset(0, 0)
    end
end

local function ApplyLook()
    main:SetScale(db.scale)
    main:SetAlpha(db.alpha)
    if db.shown then main:Show() else main:Hide() end
    main:EnableMouse(not db.locked)
    ApplyFont()
    if db.useColor then
        text:SetTextColor(db.color.r, db.color.g, db.color.b)
    else
        text:SetTextColor(1, 1, 1)
    end
end

local function ApplyPosition()
    main:ClearAllPoints()
    main:SetPoint(db.point, UIParent, db.relPoint, db.x, db.y)
end

local function Refresh()
    if not db or not main:IsShown() then return end
    local ok, str = pcall(GetStatsText)
    if not ok then str = "|cFFFF0000Vash Stats PvP error:|r\n" .. tostring(str) end
    if db.useColor then
        str = str:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    end
    -- Alinear iconos con el texto: tamano proporcional a la fuente, sin offset fijo
    local isz = (db.iconSize and db.iconSize > 0) and db.iconSize or (db.fontSize + 2)
    str = str:gsub("|T([^|]-):(%d+):(%d+):0:%-10|t", function(path, h)
        local sz = (tonumber(h) > 16) and (isz + 6) or isz
        return string.format("|T%s:%d:%d:0:%d|t", path, sz, sz, db.iconY or 0)
    end)
    if not db.showIcons then
        str = str:gsub("|T.-|t ?", "")
    end
    ApplyFont() -- necesario en 3.3.5 antes de SetText tras cambiar fuente
    text:SetWidth(800) -- ancho amplio temporal para medir sin cortar lineas
    text:SetText(str)
    local w = text:GetStringWidth()
    text:SetWidth(w + 6)
    text:SetText(str)
    main:SetSize(math.max(w + 10, 20), math.max(text:GetStringHeight() + 4, 20))
end

local function FullUpdate()
    ApplyLook()
    Refresh()
end

------------------------------------------------------------------
-- Eventos (los mismos del WeakAura + algunos extra de 3.3.5)
------------------------------------------------------------------
local events = {
    "UNIT_STATS", "UNIT_AURA", "UNIT_RESISTANCES", "UNIT_DAMAGE",
    "UNIT_ATTACK_POWER", "UNIT_RANGED_ATTACK_POWER", "UNIT_SPELL_POWER",
    "UNIT_INVENTORY_CHANGED", "PLAYER_EQUIPMENT_CHANGED", "COMBAT_RATING_UPDATE",
    "UNIT_MANA", "UNIT_HEALTH", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED",
    "PLAYER_ENTERING_WORLD", "UPDATE_SHAPESHIFT_FORM", "PLAYER_TALENT_UPDATE",
    "ACTIVE_TALENT_GROUP_CHANGED", "CHARACTER_POINTS_CHANGED",
}

local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")

local dirty, elapsed = false, 0
ev:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON then return end
        VashStatsPvPDB = VashStatsPvPDB or {}
        db = VashStatsPvPDB
        ApplyDefaults(db)
        for _, e in ipairs(events) do pcall(self.RegisterEvent, self, e) end
        ApplyPosition()
        FullUpdate()
        self:UnregisterEvent("ADDON_LOADED")
        return
    end
    if (event:find("^UNIT_")) and arg1 ~= "player" then return end
    dirty = true
end)
ev:SetScript("OnUpdate", function(self, dt)
    elapsed = elapsed + dt
    if dirty and elapsed > 0.1 then
        dirty, elapsed = false, 0
        Refresh()
    elseif elapsed > 1 then
        elapsed = 0
        Refresh()
    end
end)

------------------------------------------------------------------
-- Reset de perfil
------------------------------------------------------------------
local function ResetProfile()
    for k in pairs(db) do db[k] = nil end
    ApplyDefaults(db)
    ApplyPosition()
    FullUpdate()
    if VashStatsPvP_SyncConfig then VashStatsPvP_SyncConfig() end
    print("|cFF00FF96Vash Stats PvP:|r perfil restablecido.")
end

StaticPopupDialogs["VASHSTATSPVP_RESET"] = {
    text = "Restablecer el perfil de Vash Stats PvP a los valores por defecto?",
    button1 = YES, button2 = NO,
    OnAccept = ResetProfile,
    timeout = 0, whileDead = true, hideOnEscape = true,
}

------------------------------------------------------------------
-- Panel de configuracion
------------------------------------------------------------------
local FONTS = {
    { "Friz Quadrata TT", "Fonts\\FRIZQT__.TTF" },
    { "Arial Narrow",     "Fonts\\ARIALN.TTF" },
    { "Skurri",           "Fonts\\SKURRI.TTF" },
    { "Morpheus",         "Fonts\\MORPHEUS.TTF" },
}
do -- LibSharedMedia opcional
    local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
    if LSM then
        for _, name in ipairs(LSM:List("font")) do
            local dup = false
            for _, f in ipairs(FONTS) do if f[1] == name then dup = true end end
            if not dup then FONTS[#FONTS + 1] = { name, LSM:Fetch("font", name) } end
        end
    end
end

local OUTLINES = {
    { "Ninguno", "NONE" },
    { "Contorno", "OUTLINE" },
    { "Contorno grueso", "THICKOUTLINE" },
}

local cfg
local widgets = {}

local function MakeCheck(name, label, x, y, key, after)
    local cb = CreateFrame("CheckButton", "VashStatsPvPCfg" .. name, cfg, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", x, y)
    _G[cb:GetName() .. "Text"]:SetText(label)
    cb:SetScript("OnClick", function(self)
        db[key] = self:GetChecked() and true or false
        FullUpdate()
        if after then after() end
    end)
    widgets[name] = function() cb:SetChecked(db[key]) end
    return cb
end

local function MakeSlider(name, label, x, y, key, minV, maxV, step, fmt)
    local s = CreateFrame("Slider", "VashStatsPvPCfg" .. name, cfg, "OptionsSliderTemplate")
    s:SetPoint("TOPLEFT", x, y)
    s:SetWidth(200)
    s:SetMinMaxValues(minV, maxV)
    s:SetValueStep(step)
    _G[s:GetName() .. "Low"]:SetText(minV)
    _G[s:GetName() .. "High"]:SetText(maxV)
    local title = _G[s:GetName() .. "Text"]
    s:SetScript("OnValueChanged", function(self, v)
        v = math.floor(v / step + 0.5) * step
        db[key] = v
        title:SetText(string.format(label .. ": " .. fmt, v))
        FullUpdate()
    end)
    widgets[name] = function()
        s:SetValue(db[key])
        title:SetText(string.format(label .. ": " .. fmt, db[key]))
    end
    return s
end

local function BuildConfig()
    cfg = CreateFrame("Frame", "VashStatsPvPConfig", UIParent)
    cfg:SetSize(300, 560)
    cfg:SetPoint("CENTER")
    cfg:SetFrameStrata("DIALOG")
    cfg:SetMovable(true)
    cfg:EnableMouse(true)
    cfg:RegisterForDrag("LeftButton")
    cfg:SetScript("OnDragStart", cfg.StartMoving)
    cfg:SetScript("OnDragStop", cfg.StopMovingOrSizing)
    cfg:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    tinsert(UISpecialFrames, "VashStatsPvPConfig")

    local title = cfg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -18)
    title:SetText("|cFF00FF96Vash|r Stats PvP")

    local close = CreateFrame("Button", nil, cfg, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    -- Checks
    MakeCheck("Shown",  "Mostrar panel",        24, -45,  "shown")
    MakeCheck("Locked", "Bloquear posicion",    24, -70,  "locked")
    MakeCheck("Icons",  "Mostrar iconos",       24, -95,  "showIcons")
    MakeCheck("Shadow", "Sombra",               24, -120, "shadow")

    -- Sliders
    MakeSlider("Size",  "Tamano de fuente", 40, -165, "fontSize", 8, 32, 1, "%d")
    MakeSlider("Scale", "Escala",           40, -205, "scale", 0.5, 2, 0.05, "%.2f")
    MakeSlider("Alpha", "Opacidad",         40, -245, "alpha", 0.1, 1, 0.05, "%.2f")
    MakeSlider("IconSize", "Tamano iconos (0=auto)", 40, -285, "iconSize", 0, 32, 1, "%d")
    MakeSlider("IconY", "Iconos arriba/abajo", 40, -325, "iconY", -10, 10, 1, "%d")

    -- Fuente
    local fl = cfg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fl:SetPoint("TOPLEFT", 24, -365)
    fl:SetText("Fuente")
    local fdd = CreateFrame("Frame", "VashStatsPvPCfgFont", cfg, "UIDropDownMenuTemplate")
    fdd:SetPoint("TOPLEFT", 90, -360)
    UIDropDownMenu_SetWidth(fdd, 150)
    UIDropDownMenu_Initialize(fdd, function()
        for _, f in ipairs(FONTS) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = f[1]
            info.checked = (db.fontName == f[1])
            info.func = function()
                db.fontName, db.fontPath = f[1], f[2]
                UIDropDownMenu_SetText(fdd, f[1])
                FullUpdate()
            end
            UIDropDownMenu_AddButton(info)
        end
    end)
    widgets.Font = function() UIDropDownMenu_SetText(fdd, db.fontName) end

    -- Contorno
    local ol = cfg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    ol:SetPoint("TOPLEFT", 24, -400)
    ol:SetText("Contorno")
    local odd = CreateFrame("Frame", "VashStatsPvPCfgOutline", cfg, "UIDropDownMenuTemplate")
    odd:SetPoint("TOPLEFT", 90, -395)
    UIDropDownMenu_SetWidth(odd, 150)
    UIDropDownMenu_Initialize(odd, function()
        for _, o in ipairs(OUTLINES) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = o[1]
            info.checked = (db.outline == o[2])
            info.func = function()
                db.outline = o[2]
                UIDropDownMenu_SetText(odd, o[1])
                FullUpdate()
            end
            UIDropDownMenu_AddButton(info)
        end
    end)
    widgets.Outline = function()
        for _, o in ipairs(OUTLINES) do
            if o[2] == db.outline then UIDropDownMenu_SetText(odd, o[1]) end
        end
    end

    -- Color personalizado
    local colorCheck = MakeCheck("UseColor", "Color personalizado (reemplaza colores)", 24, -435, "useColor")
    local swatch = CreateFrame("Button", "VashStatsPvPCfgSwatch", cfg)
    swatch:SetSize(24, 24)
    swatch:SetPoint("TOPLEFT", 40, -468)
    local sbg = swatch:CreateTexture(nil, "BACKGROUND")
    sbg:SetAllPoints()
    sbg:SetTexture(1, 1, 1)
    local stex = swatch:CreateTexture(nil, "OVERLAY")
    stex:SetPoint("TOPLEFT", 2, -2)
    stex:SetPoint("BOTTOMRIGHT", -2, 2)
    stex:SetTexture(1, 1, 1)
    local slabel = cfg:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    slabel:SetPoint("LEFT", swatch, "RIGHT", 8, 0)
    slabel:SetText("Elegir color")
    swatch:SetScript("OnClick", function()
        local c = db.color
        ColorPickerFrame.func = function()
            local r, g, b = ColorPickerFrame:GetColorRGB()
            c.r, c.g, c.b = r, g, b
            stex:SetTexture(r, g, b)
            FullUpdate()
        end
        ColorPickerFrame.cancelFunc = function(prev)
            c.r, c.g, c.b = prev.r, prev.g, prev.b
            stex:SetTexture(c.r, c.g, c.b)
            FullUpdate()
        end
        ColorPickerFrame.hasOpacity = false
        ColorPickerFrame.previousValues = { r = c.r, g = c.g, b = c.b }
        ColorPickerFrame:SetColorRGB(c.r, c.g, c.b)
        ColorPickerFrame:Hide()
        ColorPickerFrame:Show()
    end)
    widgets.Swatch = function() stex:SetTexture(db.color.r, db.color.g, db.color.b) end

    -- Reset
    local reset = CreateFrame("Button", nil, cfg, "UIPanelButtonTemplate")
    reset:SetSize(130, 24)
    reset:SetPoint("BOTTOMLEFT", 24, 22)
    reset:SetText("Reset perfil")
    reset:SetScript("OnClick", function() StaticPopup_Show("VASHSTATSPVP_RESET") end)

    local center = CreateFrame("Button", nil, cfg, "UIPanelButtonTemplate")
    center:SetSize(130, 24)
    center:SetPoint("BOTTOMRIGHT", -24, 22)
    center:SetText("Centrar panel")
    center:SetScript("OnClick", function()
        db.point, db.relPoint, db.x, db.y = "CENTER", "CENTER", 0, 0
        ApplyPosition()
    end)

    local hint = cfg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("BOTTOM", 0, 52)
    hint:SetText("Arrastra el panel con click izquierdo. Shift + click derecho = config.")

    cfg:Hide()
end

function VashStatsPvP_SyncConfig()
    if not cfg then return end
    for _, fn in pairs(widgets) do fn() end
end

function VashStatsPvP_OpenConfig()
    if not db then return end
    if not cfg then BuildConfig() end
    VashStatsPvP_SyncConfig()
    if cfg:IsShown() then cfg:Hide() else cfg:Show() end
end

------------------------------------------------------------------
-- Comandos e Interface Options
------------------------------------------------------------------
SLASH_VASHSTATSPVP1 = "/vstats"
SLASH_VASHSTATSPVP2 = "/vashstats"
SlashCmdList["VASHSTATSPVP"] = function(msg)
    msg = (msg or ""):lower()
    if msg == "reset" then
        StaticPopup_Show("VASHSTATSPVP_RESET")
    elseif msg == "show" then
        db.shown = true; FullUpdate()
    elseif msg == "hide" then
        db.shown = false; FullUpdate()
    elseif msg == "lock" then
        db.locked = true; FullUpdate()
    elseif msg == "unlock" then
        db.locked = false; FullUpdate()
    else
        VashStatsPvP_OpenConfig()
    end
end

local panel = CreateFrame("Frame", "VashStatsPvPOptions")
panel.name = "Vash Stats PvP"
local pt = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
pt:SetPoint("TOPLEFT", 16, -16)
pt:SetText("Vash Stats PvP")
local pb = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
pb:SetSize(160, 24)
pb:SetPoint("TOPLEFT", 16, -50)
pb:SetText("Abrir configuracion")
pb:SetScript("OnClick", function()
    HideUIPanel(InterfaceOptionsFrame)
    HideUIPanel(GameMenuFrame)
    VashStatsPvP_OpenConfig()
end)
InterfaceOptions_AddCategory(panel)
